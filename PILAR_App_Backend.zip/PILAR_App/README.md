# PILAR - Justicia Laboral 4.0

Este es el backend inicial de la aplicación PILAR para audiencias laborales automatizadas.

## Requisitos

- Python 3.9 o superior
- FastAPI
- Uvicorn

## Instalación

1. Cloná el proyecto o descomprimí este ZIP.
2. Instalá las dependencias:

```
pip install fastapi uvicorn
```

## Ejecución

Para iniciar el servidor:

```
uvicorn main:app --reload
```

Accedé a la documentación interactiva en: [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs)
