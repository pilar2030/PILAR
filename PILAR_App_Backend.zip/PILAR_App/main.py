from fastapi import FastAPI, HTTPException, Depends
from pydantic import BaseModel
from typing import List, Optional
from uuid import uuid4
from datetime import datetime

app = FastAPI(title="PILAR - Justicia Laboral 4.0")

# Simulación de base de datos en memoria
usuarios_db = {}
causas_db = {}
notificaciones_db = []

# Modelos
class Usuario(BaseModel):
    id: str
    nombre: str
    tipo: str  # trabajador, abogado, conciliador, juez

class UsuarioCreate(BaseModel):
    nombre: str
    tipo: str

class Causa(BaseModel):
    id: str
    usuario_id: str
    descripcion: str
    estado: str  # iniciada, en proceso, finalizada
    fecha_creacion: datetime

class CausaCreate(BaseModel):
    usuario_id: str
    descripcion: str

class Notificacion(BaseModel):
    id: str
    usuario_id: str
    mensaje: str
    fecha: datetime

class NotificacionCreate(BaseModel):
    usuario_id: str
    mensaje: str

# Rutas de usuarios
@app.post("/usuarios/", response_model=Usuario)
def crear_usuario(usuario: UsuarioCreate):
    user_id = str(uuid4())
    nuevo_usuario = Usuario(id=user_id, **usuario.dict())
    usuarios_db[user_id] = nuevo_usuario
    return nuevo_usuario

@app.get("/usuarios/", response_model=List[Usuario])
def listar_usuarios():
    return list(usuarios_db.values())

# Rutas de causas
@app.post("/causas/", response_model=Causa)
def crear_causa(causa: CausaCreate):
    if causa.usuario_id not in usuarios_db:
        raise HTTPException(status_code=404, detail="Usuario no encontrado")
    causa_id = str(uuid4())
    nueva_causa = Causa(id=causa_id, estado="iniciada", fecha_creacion=datetime.now(), **causa.dict())
    causas_db[causa_id] = nueva_causa
    return nueva_causa

@app.get("/causas/", response_model=List[Causa])
def listar_causas():
    return list(causas_db.values())

@app.get("/causas/{usuario_id}", response_model=List[Causa])
def listar_causas_usuario(usuario_id: str):
    return [c for c in causas_db.values() if c.usuario_id == usuario_id]

# Rutas de notificaciones
@app.post("/notificaciones/", response_model=Notificacion)
def crear_notificacion(notificacion: NotificacionCreate):
    if notificacion.usuario_id not in usuarios_db:
        raise HTTPException(status_code=404, detail="Usuario no encontrado")
    noti_id = str(uuid4())
    nueva_noti = Notificacion(id=noti_id, fecha=datetime.now(), **notificacion.dict())
    notificaciones_db.append(nueva_noti)
    return nueva_noti

@app.get("/notificaciones/{usuario_id}", response_model=List[Notificacion])
def listar_notificaciones_usuario(usuario_id: str):
    return [n for n in notificaciones_db if n.usuario_id == usuario_id]
